package com.vmware.BootcampManagementSystem.converter;

import com.vmware.BootcampManagementSystem.dto.UserDto;
import com.vmware.BootcampManagementSystem.model.User;

import java.util.ArrayList;
import java.util.List;

public class UserConverter {

    public static void toDo(UserDto dto, User user){
        user.setUserId(dto.getUserId());
        user.setFirstName(dto.getFirstName());
        user.setLastName(dto.getLastName());
        user.setRole(dto.getRole());
        user.setPassword(dto.getPassword());
    }

    public static void toDto(User user, UserDto userDto){

        userDto.setUserId(user.getUserId());
        userDto.setFirstName(user.getFirstName());
        userDto.setLastName(user.getLastName());
        userDto.setRole(user.getRole());

        //userDto.setTeam(user.getTeam());
    }

    public static UserDto[] toDto(List<User> userList){
        if(userList == null){
            return null;
        }
        List<UserDto> userDtoList = new ArrayList<>();
        for(User u : userList){
            UserDto dto = new UserDto();
            toDto(u,dto);
            userDtoList.add(dto);
        }
        return userDtoList.toArray(new UserDto[1]);
    }


}
