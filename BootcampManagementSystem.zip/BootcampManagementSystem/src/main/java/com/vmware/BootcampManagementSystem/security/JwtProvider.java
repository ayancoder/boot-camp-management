package com.vmware.BootcampManagementSystem.security;
import com.vmware.BootcampManagementSystem.exception.BadRequestException;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.io.InputStream;
import java.security.*;
import java.security.cert.CertificateException;
import java.time.Instant;
import java.util.Date;

import static io.jsonwebtoken.Jwts.parser;
import static java.util.Date.from;

@Service
public class JwtProvider {
    private KeyStore keyStore;

    @Value("${jwt.expiration.time}")
    private Long jwtExpirationMilliseconds;

    @Value("${jwt.password}")
    private String password;

    @PostConstruct
    public void init() {
        try {
            keyStore = KeyStore.getInstance("JKS");
            InputStream resourceAsStream = getClass().getResourceAsStream("/keystore.jks");
            keyStore.load(resourceAsStream, password.toCharArray());
        } catch (KeyStoreException | CertificateException | NoSuchAlgorithmException | IOException e) {
        //    throw new BadRequestException("Exception occurred while loading keystore");
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Exception found");

        }
    }
    public String generateToken(Authentication authentication) {
        org.springframework.security.core.userdetails.User principal = (User) authentication.getPrincipal();
        PrivateKey key = null;
        try{
           key = ((PrivateKey) keyStore.getKey("bootcamp", password.toCharArray()));
        } catch (KeyStoreException | NoSuchAlgorithmException | UnrecoverableKeyException e) {
            throw new BadRequestException("Exception occured while retrieving public key from keystore");

        }
        return Jwts.builder()
                .setSubject(principal.getUsername())
                .setIssuedAt(from(Instant.now()))
                .signWith(SignatureAlgorithm.RS256 , key)
                .setExpiration(from(Instant.now().plusMillis(jwtExpirationMilliseconds)))
                .compact();
    }

    private PrivateKey getPrivateKey() {
        try {
            return( (PrivateKey) keyStore.getKey("bpptcamp", password.toCharArray()));
        } catch (KeyStoreException | NoSuchAlgorithmException | UnrecoverableKeyException e) {
            throw new BadRequestException("Exception occured while retrieving public key from keystore");
        }
    }

    public boolean validateToken(String jwt) {
        try{
            parser().setSigningKey(getPublickey()).parseClaimsJws(jwt);
            return true;

        } catch (Exception exception){
            throw new BadRequestException("token has expired");
        }
    }

    private PublicKey getPublickey() {
        try {
            return keyStore.getCertificate("bootcamp").getPublicKey();
        } catch (KeyStoreException e) {
            throw new BadRequestException("Exception occured while retrieving public key from keystore");
        }
    }

    public String getUsernameFromJWT(String token) {
        Claims claims = parser()
                .setSigningKey(getPublickey())
                .parseClaimsJws(token)
                .getBody();

        return claims.getSubject();
    }

    public String generateTokenWithUserName(String username) {
        PrivateKey key = null;
        try{
            key = ((PrivateKey) keyStore.getKey("bootcamp", password.toCharArray()));
        } catch (KeyStoreException | NoSuchAlgorithmException | UnrecoverableKeyException e) {
            throw new BadRequestException("Exception occured while retrieving public key from keystore");
        }
        return Jwts.builder()
                .setSubject(username)
                .setIssuedAt(from(Instant.now()))
                .signWith(SignatureAlgorithm.RS256 , key)
                .setExpiration(Date.from(Instant.now().plusMillis(jwtExpirationMilliseconds)))
                .compact();
    }

    public Long getJwtExpirationInMillis() {
        return jwtExpirationMilliseconds;
    }
}
