package com.vmware.BootcampManagementSystem.service;


import com.vmware.BootcampManagementSystem.exception.BadRequestException;
import com.vmware.BootcampManagementSystem.repository.AdminRepository;
import com.vmware.BootcampManagementSystem.repository.MentorRepository;
import com.vmware.BootcampManagementSystem.repository.NCGRepository;
import com.vmware.BootcampManagementSystem.model.Admin;
import com.vmware.BootcampManagementSystem.model.Mentor;
import com.vmware.BootcampManagementSystem.model.NCG;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

import static java.util.Collections.singletonList;

@Service
@AllArgsConstructor
public class UserDetailsServiceImpl implements UserDetailsService {

    @Autowired
    private final NCGRepository ncgRepository;
    @Autowired
    private final MentorRepository mentorRepository;
    @Autowired
    private final AdminRepository adminRepository;

    @Override
    @Transactional(readOnly = true)
    public UserDetails loadUserByUsername(String username) {
        NCG ncg = ncgRepository.findByUserId(username).orElse(null);
        if ( ncg != null ){
            return new org.springframework.security
                    .core.userdetails.User(ncg.getUserId(), ncg.getPassword(),
                    true, true, true,
                    true, getAuthorities("ROLE_NCG"));
        }

        Mentor mentor = mentorRepository.findByUserId(username).orElse(null);

        if ( mentor != null ){
            return new org.springframework.security
                    .core.userdetails.User(mentor.getUserId(), mentor.getPassword(),
                    true, true, true,
                    true, getAuthorities("ROLE_MENTOR"));
        }

        Admin admin = adminRepository.findByUserId(username).orElse(null);

        if ( admin != null ){
            return new org.springframework.security
                    .core.userdetails.User(admin.getUserId(), admin.getPassword(),
                    true, true, true,
                    true, getAuthorities("ROLE_ADMIN"));
        }

        throw new BadRequestException("No user " +
                "Found with username : " + username);


    }

    private Collection<? extends GrantedAuthority> getAuthorities(String role) {
        return singletonList(new SimpleGrantedAuthority(role));
    }
}