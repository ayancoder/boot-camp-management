package com.vmware.BootcampManagementSystem.repository;


import com.vmware.BootcampManagementSystem.model.RefreshToken;
import com.vmware.BootcampManagementSystem.service.RefreshTokenService;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

public interface RefreshTokenRepository extends MongoRepository<RefreshToken,String> {

    Optional<RefreshToken> findByRefreshToken(String token);

    void deleteByRefreshToken(String token);
}
