package com.vmware.BootcampManagementSystem.converter;

import com.vmware.BootcampManagementSystem.exception.BadRequestException;
import com.vmware.BootcampManagementSystem.dto.TaskDto;
import com.vmware.BootcampManagementSystem.model.Difficulty;
import com.vmware.BootcampManagementSystem.model.Task;
import com.vmware.BootcampManagementSystem.model.TaskType;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

public class TaskConverter {


    public static void toDo(TaskDto dto, Task task ){
        try{
            task.setLevel(Difficulty.valueOf(dto.getLevel()));
            task.setDescription(dto.getDescription());
            task.setTaskType(TaskType.valueOf(dto.getType()));
            task.setDeadLine(dto.getDeadLine());
            task.setTitle(dto.getTitle());
        } catch (Exception e){
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Invalid parameter");

            //throw new BadRequestException("Enum values not right");
        }

    }


    public static void toDto(Task task, TaskDto dto){
        dto.setId(task.getId());
        dto.setTitle(task.getTitle());
        dto.setDescription(task.getDescription());
        dto.setDeadLine(task.getDeadLine());
        dto.setLevel(task.getLevel().toString());
        dto.setType(task.getTaskType().toString());
    }
}
