package com.vmware.BootcampManagementSystem.service;

import com.vmware.BootcampManagementSystem.exception.BadRequestException;
import com.vmware.BootcampManagementSystem.repository.*;
import com.vmware.BootcampManagementSystem.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Set;

@Service
public class AdminService {
    private final AdminRepository adminRepository;
    @Autowired
    private final NCGRepository ncgRepository;

    @Autowired
    private final MentorRepository mentorRepository;

    @Autowired
    private final TeamRepository teamRepository;

    @Autowired
    private final TaskRepository taskRepository;

    private final SubmissionService submissionService;

    @Autowired
    public AdminService(AdminRepository ncgRepository, NCGRepository ncgRepository1, MentorRepository mentorRepository, TeamRepository teamRepository, TaskRepository taskRepository, SubmissionService submissionService) {
        this.adminRepository = ncgRepository;
        this.ncgRepository = ncgRepository1;
        this.mentorRepository = mentorRepository;
        this.teamRepository = teamRepository;
        this.taskRepository = taskRepository;
        this.submissionService = submissionService;
    }


    public void addUser(Admin user) {
        Admin admin = getUserByID(user.getUserId());
        if(admin == null ){
            adminRepository.save(user);
        } else{
            throw new BadRequestException( user.getUserId()+" already exists");
        }
    }

    public Admin getUserByID(String userId) {
        return adminRepository.findByUserId(userId).orElse(null);
    }

    public List<NCG> getAllNCG(){
        return  ncgRepository.findAll();
    }

    public List<Mentor> getAllMentor(){
        return mentorRepository.findAll();
    }

    @Transactional
    public void assignTasks(Task task){

        Task existingTask = taskRepository.findByTitle(task.getTitle()).orElse(null);
        if(existingTask == null){
            taskRepository.save(task);
        } else {
            throw new BadRequestException("Task with title already exists");
        }

        if(task.getTaskType().equals(TaskType.INDIVIDUAL)){
            List<NCG> ncgList = ncgRepository.findAll();
            for(NCG ncg : ncgList) {
                Set<Task> taskSet = ncg.getTasks();
                Set<Submission> submissionSet = ncg.getSubmissions();
                Submission submission = new Submission();

                submission.setTask(task);
                submission.setState(State.NOT_SUBMITTED);
                submission.setSubmitterId(ncg.getUserId());
                submissionService.save(submission);

                submissionSet.add(submission);
                taskSet.add(task);
                ncg.setTasks(taskSet);
                ncg.setSubmissions(submissionSet);
            }
            ncgRepository.saveAll(ncgList);
        } else {
            List<Team> teamList = teamRepository.findAll();
            for(Team team : teamList) {
                Set<Task> taskSet = team.getTaskList();
                Set<Submission> submissionSet = team.getSubmissions();
                Submission submission = new Submission();
                submission.setState(State.NOT_SUBMITTED);
                submission.setTask(task);
                submission.setSubmitterId(team.getTeamName());
                submissionService.save(submission);

                submissionSet.add(submission);
                taskSet.add(task);
                team.setSubmissions(submissionSet);
                team.setTaskList(taskSet);
            }
            teamRepository.saveAll(teamList);
        }


        }

        @Transactional
        public void assignTeamToMentor( String userId, String teamName){

            Team team = teamRepository.findByTeamName(teamName).orElse(null);

            if( team == null){
                throw new ResponseStatusException(HttpStatus.NOT_FOUND,teamName+" not found");

                //throw new BadRequestException("Team doesn't exists");
            }

            Mentor mentor = mentorRepository.findByUserId(userId).orElse(null);

            if( mentor == null){
                throw new ResponseStatusException(HttpStatus.NOT_FOUND,userId+" not found");

               // throw new BadRequestException("User doesn't exists");
            }

            mentor.setTeam(team);

            for(User u : team.getUsers()){
                List<Mentor> mentorList =  ((NCG)u).getMentors();
                mentorList.add(mentor);
                ncgRepository.save((NCG)u);
            }

            mentorRepository.save(mentor);

        }

    }


