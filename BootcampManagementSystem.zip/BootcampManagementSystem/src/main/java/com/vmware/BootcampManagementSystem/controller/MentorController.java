package com.vmware.BootcampManagementSystem.controller;

import com.vmware.BootcampManagementSystem.converter.UserConverter;
import com.vmware.BootcampManagementSystem.dto.TaskDto;
import com.vmware.BootcampManagementSystem.dto.TeamResponseDto;
import com.vmware.BootcampManagementSystem.model.Mentor;
import com.vmware.BootcampManagementSystem.service.MentorService;
import com.vmware.BootcampManagementSystem.service.NCGService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("api/mentor")
public class MentorController {


    final private MentorService mentorService;

    final private NCGService ncgService;

    @Autowired
    public MentorController(MentorService mentorService, NCGService ncgService) {
        this.mentorService = mentorService;
        this.ncgService = ncgService;
    }



    @PostMapping(path = "/{mentor_id}/user/{user_id}/task/{task_id}/evaluate")
    public void evaluateTask( @PathVariable (name = "mentor_id") String mentor_id,  @PathVariable (name = "user_id") String user_id, @PathVariable (name = "task_id") String task_id,
                             @RequestParam (name="score",required = true ) String score){
        int intScore = 0;
        try{
            intScore = Integer.parseInt(score);
        }  catch (Exception exp){
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Invalid parameter",exp);
           // throw new BadRequestException("Invalid paramter");
        }

        Mentor mentor = mentorService.getUserByID(mentor_id);
        if(mentor == null || mentor.getTeam() == null || mentor.getTeam().getUsers().stream().filter( x -> x.getUserId().equals(user_id)).findFirst().orElse(null) == null){
            //throw new BadRequestException("mentor does not exist or user not mentor's mentee");
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,mentor_id+" not found");
        }

        mentorService.evaluateIndividualTask(user_id,task_id,intScore);
    }


    @PostMapping(path = "/{mentor_id}/team/{teamName}/task/{task_id}/evaluate")
    public void evaluateTeamTask( @PathVariable (name = "mentor_id") String mentor_id,  @PathVariable (name = "teamName") String teamName, @PathVariable (name = "task_id") String task_id,
                             @RequestParam (name="score",required = true ) String score){
        int intScore = 0;
        try{
            intScore = Integer.parseInt(score);
        }  catch (Exception exp){
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Invalid parameter");
            //throw new BadRequestException("Invalid paramter");
        }
        Mentor mentor = mentorService.getUserByID(mentor_id);
        if( mentor == null || mentor.getTeam() == null || !mentor.getTeam().getTeamName().equals(teamName)){
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,mentor_id+" not found");
            //throw new BadRequestException("mentor does not exist or team doesnt exist");
        }
        mentorService.evaluateTeamTask(teamName,task_id,intScore);
    }

    @GetMapping(path = "/{mentorId}/user/{userId}/tasks")
    public List<TaskDto> getTaskById( @PathVariable (name = "mentorId") String mentorId,   @PathVariable (name = "userId") String userId, @RequestParam (name="state",required = false, defaultValue = "ALL") String state){

        Mentor mentor = mentorService.getUserByID(mentorId);
        if(mentor == null || mentor.getTeam() == null || mentor.getTeam().getUsers().stream().filter( x -> x.getUserId().equals(userId)).findFirst().orElse(null) == null){
            //throw new BadRequestException("mentor does not exist or user not mentor's mentee");
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,mentorId +" not found");

        }
        List<TaskDto> taskDtos =  ncgService.getTaskByUserId(userId);
        if(!state.equals("ALL")){
            taskDtos =  taskDtos.stream().filter(taskDto -> taskDto.getState().equals(state)).collect(Collectors.toList());
            return taskDtos;
        }
        return taskDtos;
    }

    @GetMapping(path = "/{mentorId}/team/{teamName}/tasks")
    public List<TaskDto> getTaskByTeamName( @PathVariable (name = "mentorId") String userId,   @PathVariable (name = "teamName") String teamName, @RequestParam (name="state",required = false, defaultValue = "ALL") String state){

        Mentor mentor = mentorService.getUserByID(userId);
        if( mentor == null || mentor.getTeam() == null || !mentor.getTeam().getTeamName().equals(teamName)){
            //throw new BadRequestException("mentor does not exist or team doesnt exist");
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,userId+" not found");

        }

        List<TaskDto> taskDtos = ncgService.getTaskByTeamName(teamName);
        if(!state.equals("ALL")){
            taskDtos =  taskDtos.stream().filter(taskDto -> taskDto.getState().equals(state)).collect(Collectors.toList());
            return taskDtos;
        }
        return taskDtos;
    }

    @GetMapping(path = "{mentorId}/team")
    public TeamResponseDto getTeam(  @PathVariable (name = "mentorId") String userId ){
        Mentor mentor = mentorService.getUserByID(userId);
        if ( mentor == null || mentor.getTeam() == null ){
            //throw  new BadRequestException("mentor doesn't exist");
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,userId+" not found");

        }
        TeamResponseDto teamResponseDto = new TeamResponseDto();
        teamResponseDto.setTeamId(mentor.getTeam().getId());
        teamResponseDto.setTeamName(mentor.getTeam().getTeamName());
        teamResponseDto.setUsers(UserConverter.toDto(mentor.getTeam().getUsers()));
        return teamResponseDto;
    }


}
