package com.vmware.BootcampManagementSystem.model;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.validation.constraints.NotBlank;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Document
public class Task {
    @Id
    private String id;
    @NotBlank(message = "Title needed")
    private String title;

    private Difficulty level;
    @NotBlank(message = "Description needed")
    private String description;
    @NotBlank(message = "Date needed")
    long deadLine;
    private TaskType taskType;

    private boolean isAddedToLeaderboard = false;



}
