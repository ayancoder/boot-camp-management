package com.vmware.BootcampManagementSystem.converter;

import com.vmware.BootcampManagementSystem.dto.UserDto;
import com.vmware.BootcampManagementSystem.model.Mentor;

public class MentorConverter {
    public static void toDo(UserDto dto, Mentor ncg){
        UserConverter.toDo(dto,ncg);
    }
/*
    public static void toDto(Mentor ncg,NCGDto ncgDto){
        UserConverter.toDto(ncg,ncgDto);
        ncgDto.setTeam(TeamConverter.toDto(ncg.getTeam()));
        //ncgDto.setMentors(UserConverter.toDto(ncg.getMentors()));

    }*/
}
