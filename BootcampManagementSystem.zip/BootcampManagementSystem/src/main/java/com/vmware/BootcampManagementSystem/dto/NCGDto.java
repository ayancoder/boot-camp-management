package com.vmware.BootcampManagementSystem.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.vmware.BootcampManagementSystem.model.User;
import lombok.*;
import lombok.experimental.Accessors;


@Data
@Getter
@Setter
@Accessors(chain = true)
@NoArgsConstructor
@ToString
@JsonInclude(value = JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class NCGDto extends UserDto {

    @JsonProperty("mentors")
    private UserDto[] mentors;
    @JsonProperty("team")
    private String  team;

}
