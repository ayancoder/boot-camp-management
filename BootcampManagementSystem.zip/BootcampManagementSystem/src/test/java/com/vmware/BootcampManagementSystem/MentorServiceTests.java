package com.vmware.BootcampManagementSystem;

import com.vmware.BootcampManagementSystem.exception.BadRequestException;
import com.vmware.BootcampManagementSystem.model.*;
import com.vmware.BootcampManagementSystem.repository.NCGRepository;
import com.vmware.BootcampManagementSystem.repository.SubmissionRepository;
import com.vmware.BootcampManagementSystem.repository.TeamRepository;
import com.vmware.BootcampManagementSystem.service.MentorService;
import com.vmware.BootcampManagementSystem.service.NCGService;
import com.vmware.BootcampManagementSystem.service.SubmissionService;
import org.apache.coyote.Response;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.server.ResponseStatusException;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

@RunWith(SpringRunner.class)
@SpringBootTest
public class MentorServiceTests {


    @Mock
    private NCGRepository ncgRepository;
    @Mock
    private SubmissionService submissionService;

    @Mock
    private SubmissionRepository submissionRepository;


    @Mock
    private TeamRepository teamRepository;

    @InjectMocks
    private MentorService mentorService;


    /**
     * Positive Test case for evaluating tasks to individual
     */
    @Test
    public void evaluateTaskbyUserIdPassTest(){
        String userId = "doken";
        String taskId = "1";
        int score = 8;
        Task task1 = new Task("1","title1", Difficulty.EASY,"description",123, TaskType.INDIVIDUAL,false);
        Task task2 = new Task("2","title2", Difficulty.EASY,"description",123, TaskType.INDIVIDUAL,false);
        Submission submission1 = new Submission("1",task1,0,userId, State.SUBMITTED,"ans");
        Submission submission2 = new Submission("2",task2,0,"user2",State.NOT_SUBMITTED,"ans");

        Set<Task> taskList = new HashSet<>();
        taskList.add(task1);
        taskList.add(task2);

        Set<Submission> submissionSet = new HashSet<>();
        submissionSet.add(submission1);
        submissionSet.add(submission2);

        NCG ncg = new NCG();
        ncg.setId("1");
        ncg.setUserId(userId);
        ncg.setTeamName("team1");
        ncg.setFirstName("niket");
        ncg.setSubmissions(submissionSet);
        ncg.setTasks(taskList);

        when(ncgRepository.findByUserId(userId)).thenReturn(java.util.Optional.of(ncg));
        when(submissionService.findByUserIdWithTask(userId,task1)).thenReturn(submission1);
        when(submissionService.findByUserIdWithTask(userId,task2)).thenReturn(submission2);
        when(submissionRepository.save(submission1)).thenReturn(submission1);
        Submission result = new Submission("1",task1,score,userId,State.EVALUATED,"ans");

        mentorService.evaluateIndividualTask(userId,taskId,score);

        assertEquals(result,submission1);
    }

    /**
     *  Test case for task not found exception for individual
     */
    @Test
    public void evaluateTaskbyUserIdThrowExceptionTaskNotFound(){
        String userId = "doken";
        String taskId = "2";
        int score = 8;
        Task task1 = new Task("1","title1", Difficulty.EASY,"description",123, TaskType.INDIVIDUAL,false);
        Task task2 = new Task("2","title2", Difficulty.EASY,"description",123, TaskType.INDIVIDUAL,false);
        Submission submission1 = new Submission("1",task1,0,userId, State.SUBMITTED,"ans");
        Submission submission2 = new Submission("2",task2,0,"user2",State.NOT_SUBMITTED,"ans");

        Set<Task> taskList = new HashSet<>();
        taskList.add(task1);
        taskList.add(task2);

        Set<Submission> submissionSet = new HashSet<>();
        submissionSet.add(submission1);
        submissionSet.add(submission2);

        NCG ncg = new NCG();
        ncg.setId("1");
        ncg.setUserId(userId);
        ncg.setTeamName("team1");
        ncg.setFirstName("niket");
        ncg.setSubmissions(submissionSet);
        ncg.setTasks(taskList);

        when(ncgRepository.findByUserId(userId)).thenReturn(java.util.Optional.of(ncg));
        when(submissionService.findByUserIdWithTask(userId,task1)).thenReturn(submission1);
        when(submissionService.findByUserIdWithTask(userId,task2)).thenReturn(submission2);
        when(submissionRepository.save(submission1)).thenReturn(submission1);
        Submission result = new Submission("1",task2,score,userId,State.EVALUATED,"ans");

        assertThrows(ResponseStatusException.class, ()->{
            mentorService.evaluateIndividualTask(userId,taskId,score);

        });

    }


    /**
     * Positive Test case for evaluating tasks for team
     */
    @Test
    public void evaluateTaskbyTeamNamePassTest(){
        String teamName = "team1";
        String taskId = "1";
        int score = 8;
        Task task1 = new Task("1","title1", Difficulty.EASY,"description",123, TaskType.TEAM,false);
        Task task2 = new Task("2","title2", Difficulty.EASY,"description",123, TaskType.TEAM,false);
        Submission submission1 = new Submission("1",task1,0,teamName, State.SUBMITTED,"ans");
        Submission submission2 = new Submission("2",task2,0,"team2",State.NOT_SUBMITTED,"ans");

        Set<Task> taskList = new HashSet<>();
        taskList.add(task1);
        taskList.add(task2);

        Set<Submission> submissionSet = new HashSet<>();
        submissionSet.add(submission1);
        submissionSet.add(submission2);

        NCG ncg = new NCG();
        ncg.setId("1");
        ncg.setUserId("userId");
        ncg.setTeamName("team1");
        ncg.setFirstName("niket");
        ncg.setSubmissions(submissionSet);
        ncg.setTasks(taskList);

        List<User> ncgList = new ArrayList<>();
        ncgList.add(ncg);

        Team team = new Team("1", "team1", ncgList, taskList, submissionSet, false);

        when(teamRepository.findByTeamName(teamName)).thenReturn(java.util.Optional.of(team));
        when(submissionService.findByUserIdWithTask(teamName,task1)).thenReturn(submission1);
        when(submissionService.findByUserIdWithTask(teamName,task2)).thenReturn(submission2);
        when(submissionRepository.save(submission1)).thenReturn(submission1);
        Submission result = new Submission("1",task1,score,teamName,State.EVALUATED,"ans");

        mentorService.evaluateTeamTask(teamName,taskId,score);

        assertEquals(result,submission1);

    }

    /**
     * Positive Test case for evaluating tasks not submitted
     */
    @Test
    public void evaluateTaskbyTeamNameThrowException(){
        String teamName = "team1";
        String taskId = "1";
        int score = 8;
        Task task1 = new Task("1","title1", Difficulty.EASY,"description",123, TaskType.INDIVIDUAL,false);
        Task task2 = new Task("2","title2", Difficulty.EASY,"description",123, TaskType.TEAM,false);
        Submission submission1 = new Submission("1",task1,0,teamName, State.SUBMITTED,"ans");
        Submission submission2 = new Submission("2",task2,0,"team2",State.NOT_SUBMITTED,"ans");

        Set<Task> taskList = new HashSet<>();
        taskList.add(task1);
        taskList.add(task2);

        Set<Submission> submissionSet = new HashSet<>();
        submissionSet.add(submission1);
        submissionSet.add(submission2);

        NCG ncg = new NCG();
        ncg.setId("1");
        ncg.setUserId("userId");
        ncg.setTeamName("team1");
        ncg.setFirstName("niket");
        ncg.setSubmissions(submissionSet);
        ncg.setTasks(taskList);

        List<User> ncgList = new ArrayList<>();
        ncgList.add(ncg);

        Team team = new Team("1", "team1", ncgList, taskList, submissionSet, false);

        when(teamRepository.findByTeamName(teamName)).thenReturn(java.util.Optional.of(team));
        when(submissionService.findByUserIdWithTask(teamName,task1)).thenReturn(submission1);
        when(submissionService.findByUserIdWithTask(teamName,task2)).thenReturn(submission2);
        when(submissionRepository.save(submission1)).thenReturn(submission1);
        Submission result = new Submission("1",task1,score,teamName,State.EVALUATED,"ans");

        assertThrows(BadRequestException.class , ()->
            mentorService.evaluateTeamTask(teamName,taskId,score)
        );

    }


}
