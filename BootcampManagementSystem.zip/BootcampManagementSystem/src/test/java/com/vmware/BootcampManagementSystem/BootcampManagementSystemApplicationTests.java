package com.vmware.BootcampManagementSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootcampManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
