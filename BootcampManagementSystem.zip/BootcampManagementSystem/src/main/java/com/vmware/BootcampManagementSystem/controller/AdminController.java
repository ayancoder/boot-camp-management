package com.vmware.BootcampManagementSystem.controller;

import com.vmware.BootcampManagementSystem.converter.TaskConverter;
import com.vmware.BootcampManagementSystem.converter.UserConverter;
import com.vmware.BootcampManagementSystem.dto.TeamResponseDto;
import com.vmware.BootcampManagementSystem.dto.UserDto;
import com.vmware.BootcampManagementSystem.dto.TaskDto;
import com.vmware.BootcampManagementSystem.dto.TeamDto;
import com.vmware.BootcampManagementSystem.model.*;
import com.vmware.BootcampManagementSystem.repository.TaskRepository;
import com.vmware.BootcampManagementSystem.service.AdminService;
import com.vmware.BootcampManagementSystem.service.NCGService;
import com.vmware.BootcampManagementSystem.service.TeamService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import javax.validation.Valid;
import java.util.*;

@RestController
@RequestMapping("api/admin")
public class AdminController {

    @Autowired
    private final AdminService adminService;

    private final NCGService ncgService;

    private final TeamService teamService;

    private final TaskRepository taskRepository;


    public AdminController(AdminService adminService, NCGService ncgService, TeamService teamService, TaskRepository taskRepository) {
        this.adminService = adminService;
        this.ncgService = ncgService;
        this.teamService = teamService;
        this.taskRepository = taskRepository;
    }

    @GetMapping(path = "/users")
    public List<UserDto> getAllNCG(){
        List<NCG> ncgList = adminService.getAllNCG();
        List<UserDto> userDtoList = new ArrayList<>();
        for(NCG ncg : ncgList){
            UserDto userDto = new UserDto();
            UserConverter.toDto(ncg,userDto);
            userDtoList.add(userDto);
        }
        return userDtoList;
    }

    @GetMapping(path = "/mentors")
    public List<UserDto> getAllMentor(){
        List<Mentor> ncgList = adminService.getAllMentor();
        List<UserDto> userDtoList = new ArrayList<>();
        for(Mentor mentor : ncgList){
            UserDto userDto = new UserDto();
            UserConverter.toDto(mentor,userDto);
            userDtoList.add(userDto);
        }
        return userDtoList;
    }

    @PostMapping(path = "/tasks")
    public void assignTasks(@RequestBody TaskDto taskDto){

        Task task = new Task();
        TaskConverter.toDo(taskDto, task);
        adminService.assignTasks(task);

    }

    @GetMapping(path = "tasks")
    public List<Task> getAllTasks(){
           return taskRepository.findAll();
    }

    @Transactional
    @PostMapping(path="/team/add")
    public void addTeam(@RequestBody @Valid TeamDto teamDto) {
        Team team = new Team();
        team.setTeamName(teamDto.getTeamName());
        List<String> userList = Arrays.asList(teamDto.getUsers());
        Set<String> userSet = new HashSet<>(userList);
        System.out.println("user set "+userSet);
        List<User> users = new ArrayList<>();
        for(String s : userSet){
            NCG ncg = ncgService.findByUserId(s);
            if(ncg != null && ncg.getTeamName() == null){
                ncg.setTeamName(teamDto.getTeamName());
                ncgService.save(ncg);
                users.add(ncg);
            } else{
                throw new ResponseStatusException(HttpStatus.NOT_FOUND,s+" not found ");
                //throw new BadRequestException("user_id do not exist");
            }
        }

        team.setUsers(users);
        teamService.addTeam(team);

    }

    @PostMapping(path = "/mentor/{user_id}/team/{team_id}")
    public void assignMentorToTeam( @PathVariable(name = "user_id") String userId,@PathVariable(name = "team_id") String teamId ){
        adminService.assignTeamToMentor(userId,teamId);
    }


    @GetMapping(path = "/teams")
    public List<TeamResponseDto> getAllTeam(){

       List<TeamResponseDto> teamResponseDtoList = new ArrayList<>();

        List<Team> teamList = teamService.findAll();
        for(Team team : teamList ){
            TeamResponseDto teamResponseDto = new TeamResponseDto();
            teamResponseDto.setTeamId(team.getId());
            teamResponseDto.setTeamName(team.getTeamName());
            teamResponseDto.setUsers(UserConverter.toDto(team.getUsers()));
            teamResponseDtoList.add(teamResponseDto);
        }

        return teamResponseDtoList;
        //return TeamConverter.toDto(team);
    }





}
