package com.vmware.BootcampManagementSystem.repository;

import com.vmware.BootcampManagementSystem.model.User;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

public interface UserRepository extends MongoRepository<User,String> {


    Optional<User> findById(String s);

    Optional<User> findByUserId(String s);


}
