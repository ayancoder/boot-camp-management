package com.vmware.BootcampManagementSystem.model;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

//import javax.persistence.Id;
import javax.validation.constraints.NotBlank;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class User {

    @Id
    private String id;
    @NotBlank(message = "userId required")
    private  String userId;
    @NotBlank(message = "firstName required")
    private  String firstName;
    @NotBlank(message = "lastName required")
    private  String lastName;
    @NotBlank(message = "password required")
    private  String password;
    @NotBlank(message = "role require")
    private  String role;


}
