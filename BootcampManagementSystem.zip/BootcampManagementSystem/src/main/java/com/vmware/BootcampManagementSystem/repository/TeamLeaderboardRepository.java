package com.vmware.BootcampManagementSystem.repository;

import com.vmware.BootcampManagementSystem.model.TeamLeaderBoard;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

public interface TeamLeaderboardRepository extends MongoRepository <TeamLeaderBoard, String> {

    Optional<TeamLeaderBoard> findByUserId(String userId);

}
