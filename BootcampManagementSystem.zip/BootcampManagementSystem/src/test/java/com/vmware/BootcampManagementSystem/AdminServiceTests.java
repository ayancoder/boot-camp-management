package com.vmware.BootcampManagementSystem;

import com.vmware.BootcampManagementSystem.dto.TaskDto;
import com.vmware.BootcampManagementSystem.model.*;
import com.vmware.BootcampManagementSystem.repository.NCGRepository;
import com.vmware.BootcampManagementSystem.repository.SubmissionRepository;
import com.vmware.BootcampManagementSystem.repository.TaskRepository;
import com.vmware.BootcampManagementSystem.repository.TeamRepository;
import com.vmware.BootcampManagementSystem.service.AdminService;
import com.vmware.BootcampManagementSystem.service.MentorService;
import com.vmware.BootcampManagementSystem.service.SubmissionService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@RunWith(SpringRunner.class)
@SpringBootTest
public class AdminServiceTests {

    @Mock
    private NCGRepository ncgRepository;
    @Mock
    private SubmissionService submissionService;

    @Mock
    private SubmissionRepository submissionRepository;

    @Mock
    private TaskRepository taskRepository;


    @Mock
    private TeamRepository teamRepository;

    @InjectMocks
    private AdminService adminService;


    /**
     * Positive Test case for assigning tasks
     */
    @Test
    public void assignTaskPassTest(){

        Task task = new Task("3","title3", Difficulty.EASY,"description",123, TaskType.INDIVIDUAL,false);

        Task task1 = new Task("1","title1", Difficulty.EASY,"description",123, TaskType.INDIVIDUAL,false);
        Task task2 = new Task("2","title2", Difficulty.EASY,"description",123, TaskType.INDIVIDUAL,false);
        Submission submission1 = new Submission("1",task1,0,"u1", State.NOT_SUBMITTED,null);
        Submission submission2 = new Submission("2",task2,0,"u2",State.NOT_SUBMITTED,null);

        Set<Task> taskList = new HashSet<>();
        taskList.add(task1);
        taskList.add(task2);

        Set<Submission> submissionSet = new HashSet<>();
        submissionSet.add(submission1);
        submissionSet.add(submission2);

        NCG ncg1 = new NCG();
        ncg1.setId("1");
        ncg1.setUserId("u1");
        ncg1.setTeamName("team1");
        ncg1.setFirstName("niket");
        ncg1.setSubmissions(submissionSet);
        ncg1.setTasks(taskList);
        Submission submission3 = new Submission(null,task,0,"u1", State.NOT_SUBMITTED,null);

        NCG ncg2 = new NCG();
        ncg2.setId("2");
        ncg2.setUserId("u2");
        ncg2.setTeamName("team1");
        ncg2.setFirstName("niket");
        ncg2.setSubmissions(submissionSet);
        ncg2.setTasks(taskList);
        Submission submission4 = new Submission(null,task,0,"u2", State.NOT_SUBMITTED,null);

        List<NCG> ncgList = new ArrayList<>();
        ncgList.add(ncg1);
        ncgList.add(ncg2);

        Team team1 = new Team("1", "team1", null, taskList, submissionSet, false);
        Team team2 = new Team("2", "team2", null, taskList, submissionSet, false);

        List<Team> teamList = new ArrayList<>();
        teamList.add(team1);
        teamList.add(team2);

        Set<Task> expectedTaskList = new HashSet<>();
        expectedTaskList.add(task1);
        expectedTaskList.add(task2);
        expectedTaskList.add(task);

        Set<Submission> expectedSubmissionList = new HashSet<>();
        expectedSubmissionList.add(submission1);
        expectedSubmissionList.add(submission2);
        expectedSubmissionList.add(submission3);
        expectedSubmissionList.add(submission4);

        //when(taskRepository.findByTitle(task.getTitle())).thenReturn(java.util.Optional.of(task));
        when(taskRepository.findByTitle(task.getTitle())).thenReturn(java.util.Optional.empty());
        when(adminService.getAllNCG()).thenReturn(ncgList);
        when(teamRepository.findAll()).thenReturn(teamList);
        when(submissionRepository.save(submission3)).thenReturn(submission3);
        when(submissionRepository.save(submission4)).thenReturn(submission4);
        when(ncgRepository.saveAll(ncgList)).thenReturn(ncgList);
        when(teamRepository.saveAll(teamList)).thenReturn(teamList);

        adminService.assignTasks(task);


        for(NCG ncg : ncgList){
            assertEquals(expectedSubmissionList,ncg.getSubmissions());
            assertEquals(expectedTaskList,ncg.getTasks());
        }

    }
}
