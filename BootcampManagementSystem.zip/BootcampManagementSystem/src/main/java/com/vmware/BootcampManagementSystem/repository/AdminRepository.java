package com.vmware.BootcampManagementSystem.repository;

import com.vmware.BootcampManagementSystem.model.Admin;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

public interface AdminRepository extends MongoRepository<Admin,String> {
    @Override
    Optional<Admin> findById(String s);
    Optional<Admin> findByUserId(String s);
}