package com.vmware.BootcampManagementSystem.converter;


import com.vmware.BootcampManagementSystem.dto.NCGDto;
import com.vmware.BootcampManagementSystem.model.NCG;

public class NCGConverter extends UserConverter {

    public static void toDo(NCGDto dto, NCG ncg){

        UserConverter.toDo(dto,ncg);


    }

    public static void toDto(NCG ncg,NCGDto ncgDto){
        UserConverter.toDto(ncg,ncgDto);
        ncgDto.setTeam( ncg.getTeamName());
        //ncgDto.setMentors(UserConverter.toDto(ncg.getMentors()));

    }

    }
