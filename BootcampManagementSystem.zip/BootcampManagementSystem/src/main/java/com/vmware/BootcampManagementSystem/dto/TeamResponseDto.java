package com.vmware.BootcampManagementSystem.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.vmware.BootcampManagementSystem.model.User;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TeamResponseDto {
    private String teamId;
    @NotBlank
    private  String teamName;
    @NotBlank
    private  UserDto[] users;

    public TeamResponseDto(@JsonProperty("team_name") String teamName,
                   @JsonProperty("users") UserDto[] users){
        this.teamName =teamName;
        this.users = users;

    }
}
