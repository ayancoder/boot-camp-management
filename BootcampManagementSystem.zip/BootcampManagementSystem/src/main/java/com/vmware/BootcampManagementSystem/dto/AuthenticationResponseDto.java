package com.vmware.BootcampManagementSystem.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.vmware.BootcampManagementSystem.model.User;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AuthenticationResponseDto {

    @JsonProperty("authentication_token")
    private String authenticationToken;
    @JsonProperty("user")
    private UserDto user;
    @JsonProperty("refreshToken")
    private String refreshToken;
    @JsonProperty("expires_at")
    private Instant expiresAt;
}