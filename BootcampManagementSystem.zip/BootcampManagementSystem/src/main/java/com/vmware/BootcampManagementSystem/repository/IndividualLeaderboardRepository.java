package com.vmware.BootcampManagementSystem.repository;

import com.vmware.BootcampManagementSystem.model.IndividualLeaderboard;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

public interface IndividualLeaderboardRepository extends MongoRepository<IndividualLeaderboard,String> {
    Optional<IndividualLeaderboard> findByUserId(String userId);
}
