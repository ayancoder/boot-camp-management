package com.vmware.BootcampManagementSystem.model;

 public enum State {
    SUBMITTED("SUBMITTED"),
    EVALUATED("EVALUATED"),
    NOT_SUBMITTED("NOT_SUBMITTED");

    private final String state;

    State(String state){
        this.state = state;
    }

    public String getLevel(){
        return  state;
    }
}
