package com.vmware.BootcampManagementSystem.model;


public enum TaskType {
    INDIVIDUAL("INDIVIDUAL"),
    TEAM("TEAM");


    private final String type;

    TaskType(String type){
        this.type = type;
    }

    public String getType(){
        return  type;
    }

}
