package com.vmware.BootcampManagementSystem.util;

import com.vmware.BootcampManagementSystem.repository.*;
import com.vmware.BootcampManagementSystem.model.*;
import com.vmware.BootcampManagementSystem.service.SubmissionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import static java.util.Comparator.comparing;

@Component

public class LeaderboardThread {

    private TaskRepository taskRepository;

    private SubmissionService submissionService;

    private IndividualLeaderboardRepository individualLeaderboardRepository;

    private TeamLeaderboardRepository teamLeaderboardRepository;

    private NCGRepository ncgRepository;

    private TeamRepository teamRepository;



    @Autowired
    public LeaderboardThread(TaskRepository taskRepository, SubmissionService submissionService, IndividualLeaderboardRepository individualLeaderboardRepository, TeamLeaderboardRepository teamLeaderboardRepository) {
        this.taskRepository = taskRepository;
        this.submissionService = submissionService;
        this.individualLeaderboardRepository = individualLeaderboardRepository;
        this.teamLeaderboardRepository = teamLeaderboardRepository;
    }

    private int getHighestScore(Task task){

        if(task.getLevel().equals(Difficulty.DIFFICULT)){
            return 100;
        } else if(task.getLevel().equals(Difficulty.MEDIUM)){
            return 50 ;
        } else {
            return 20 ;
        }
    }


    @Scheduled(fixedDelay = 500000)
    public void run() {

        System.out.println("Cron job running lol\n");
        List<Task> taskList = taskRepository.findAll();

        Date now = new Date();
        for(Task task : taskList){
            if( task.getDeadLine() < now.getTime()){

                if(task.getTaskType().equals(TaskType.INDIVIDUAL) && ! task.isAddedToLeaderboard()){


                    List<Submission> submissionList = submissionService.findAllByTask(task);

                    if(submissionList == null){
                        continue;
                    }
                    submissionList =  submissionList.stream().filter(x->x.getState().equals(State.EVALUATED)).collect(Collectors.toList());
                    submissionList.sort( Comparator.comparingInt(Submission::getScore));

                    if(submissionList.size() == 0){

                        continue;
                    }
                    int maxScore = submissionList.get(submissionList.size()-1).getScore();

                    for(Submission submission : submissionList){

                        IndividualLeaderboard individualLeaderboard = individualLeaderboardRepository.findByUserId(submission.getSubmitterId()).orElse(null);

                        if( individualLeaderboard == null ){
                            individualLeaderboard = new IndividualLeaderboard();
                            individualLeaderboard.setUserId(submission.getSubmitterId());
                        }

                        int newScore = ((submission.getScore()*getHighestScore(task))/maxScore );
                        System.out.println(newScore+" "+submission.getScore()+" "+getHighestScore(task)+" "+maxScore);

                        individualLeaderboard.setScore(individualLeaderboard.getScore()+newScore);
                        individualLeaderboardRepository.save(individualLeaderboard);
                    }
                    task.setAddedToLeaderboard(true);
                    taskRepository.save(task);

                } else if (task.getTaskType().equals(TaskType.TEAM) && ! task.isAddedToLeaderboard()){

                    List<Submission> submissionList = submissionService.findAllByTask(task);

                    if(submissionList == null){
                        continue;
                    }
                    submissionList =  submissionList.stream().filter(x->x.getState().equals(State.EVALUATED)).collect(Collectors.toList());
                    submissionList.sort( Comparator.comparingInt(Submission::getScore));

                    if(submissionList.size() == 0){

                        continue;
                    }
                    int maxScore = submissionList.get(submissionList.size()-1).getScore();

                    for(Submission submission : submissionList){

                        TeamLeaderBoard teamLeaderBoard = teamLeaderboardRepository.findByUserId(submission.getSubmitterId()).orElse(null);
                        if( teamLeaderBoard == null ){
                            teamLeaderBoard = new TeamLeaderBoard();
                            teamLeaderBoard.setUserId(submission.getSubmitterId());
                        }

                        int newScore = ((submission.getScore()*getHighestScore(task))/maxScore );

                        teamLeaderBoard.setScore(teamLeaderBoard.getScore()+newScore);
                        teamLeaderboardRepository.save(teamLeaderBoard);
                    }
                    task.setAddedToLeaderboard(true);
                    taskRepository.save(task);
                }


            }
        }



    }
}
