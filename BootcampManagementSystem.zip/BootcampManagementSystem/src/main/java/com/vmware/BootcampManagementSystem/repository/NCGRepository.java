package com.vmware.BootcampManagementSystem.repository;

import com.vmware.BootcampManagementSystem.model.NCG;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;


public interface NCGRepository extends MongoRepository<NCG,String> {
    @Override
    Optional<NCG> findById(String s);
    Optional<NCG> findByUserId(String s);
}
