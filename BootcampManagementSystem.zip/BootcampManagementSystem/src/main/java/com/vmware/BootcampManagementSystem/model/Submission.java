package com.vmware.BootcampManagementSystem.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.validation.constraints.NotBlank;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Document
public class Submission {
    @Id
    private String id;
    @DBRef
    private Task task;

    private int score ;

    @NotBlank
    private String submitterId;

    private State state;


    String ans;



}
