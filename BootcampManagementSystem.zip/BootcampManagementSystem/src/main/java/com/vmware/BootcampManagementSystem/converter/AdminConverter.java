package com.vmware.BootcampManagementSystem.converter;

import com.vmware.BootcampManagementSystem.dto.UserDto;
import com.vmware.BootcampManagementSystem.model.Admin;

public class AdminConverter {
    public static void toDo(UserDto dto, Admin ncg){
        UserConverter.toDo(dto,ncg);
    }
}
