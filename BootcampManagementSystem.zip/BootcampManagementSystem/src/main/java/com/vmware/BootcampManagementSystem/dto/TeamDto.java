package com.vmware.BootcampManagementSystem.dto;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import lombok.experimental.Accessors;
import javax.validation.constraints.NotBlank;


@Data
@Accessors(chain = true)
@NoArgsConstructor
@AllArgsConstructor
@ToString
@JsonInclude(value = JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class TeamDto {


    private String teamId;
    @NotBlank
    private  String teamName;
    @NotBlank
    private  String[] users;

    public TeamDto(@JsonProperty("team_name") String teamName,
                    @JsonProperty("users") String[] users){
        this.teamName =teamName;
        this.users = users;

    }
}










