package com.vmware.BootcampManagementSystem;


import com.vmware.BootcampManagementSystem.dto.TaskDto;
import com.vmware.BootcampManagementSystem.exception.BadRequestException;
import com.vmware.BootcampManagementSystem.model.*;
import com.vmware.BootcampManagementSystem.repository.NCGRepository;
import com.vmware.BootcampManagementSystem.repository.SubmissionRepository;
import com.vmware.BootcampManagementSystem.repository.TeamRepository;
import com.vmware.BootcampManagementSystem.service.NCGService;
import com.vmware.BootcampManagementSystem.service.SubmissionService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.server.ResponseStatusException;


import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(SpringRunner.class)
@SpringBootTest
public class NCGServiceUnitTests {

    @Mock
    private NCGRepository ncgRepository;
    @Mock
    private SubmissionService submissionService;

    @Mock
    private TeamRepository teamRepository;

    @InjectMocks
    private NCGService ncgService;


    /**
     * Positive Test case for getting tasks for user for individual
     */

    @Test
    public void getTaskByUserIdPassTest(){

        String userId = "doken";

        Task task1 = new Task("1","title1", Difficulty.EASY,"description",123, TaskType.INDIVIDUAL,false);
        Task task2 = new Task("2","title2", Difficulty.EASY,"description",123, TaskType.INDIVIDUAL,false);
        Submission submission1 = new Submission("1",task1,0,userId,State.NOT_SUBMITTED,null);
        Submission submission2 = new Submission("2",task2,0,userId,State.NOT_SUBMITTED,null);

        Set<Task> taskList = new HashSet<>();
        taskList.add(task1);
        taskList.add(task2);

        Set<Submission> submissionSet = new HashSet<>();
        submissionSet.add(submission1);
        submissionSet.add(submission2);

        NCG ncg = new NCG();
        ncg.setId("1");
        ncg.setUserId(userId);
        ncg.setTeamName("team1");
        ncg.setFirstName("niket");
        ncg.setSubmissions(submissionSet);
        ncg.setTasks(taskList);

        when(ncgRepository.findByUserId(userId)).thenReturn(java.util.Optional.of(ncg));
        when(submissionService.findByUserIdWithTask(userId,task1)).thenReturn(submission1);
        when(submissionService.findByUserIdWithTask(userId,task2)).thenReturn(submission1);

        TaskDto taskDto1 = new TaskDto("1","title1","description","INDIVIDUAL","EASY",123,0,"NOT_SUBMITTED",null);
        TaskDto taskDto2 = new TaskDto("2","title2","description","INDIVIDUAL","EASY",123,0,"NOT_SUBMITTED",null);
        List<TaskDto> taskDtoList = new ArrayList<>();
        taskDtoList.add(taskDto1);
        taskDtoList.add(taskDto2);

        List<TaskDto> resdtoList = ncgService.getTaskByUserId(userId);
        resdtoList.sort((a1, a2) -> Integer.parseInt(a1.getId()) - Integer.parseInt(a2.getId()));
        assertEquals(taskDtoList, resdtoList);


    }

    /**
     * Positive Test case for assigning tasks for individual
     */
    @Test
    public void shouldThrowExceptionWhileGettingTasksUserNotFound(){

        String userId = "doken";

        Task task1 = new Task("1","title1", Difficulty.EASY,"description",123, TaskType.INDIVIDUAL,false);
        Task task2 = new Task("2","title2", Difficulty.EASY,"description",123, TaskType.INDIVIDUAL,false);
        Submission submission1 = new Submission("1",task1,0,userId,State.NOT_SUBMITTED,null);
        Submission submission2 = new Submission("2",task2,0,userId,State.NOT_SUBMITTED,null);

        Set<Task> taskList = new HashSet<>();
        taskList.add(task1);
        taskList.add(task2);

        Set<Submission> submissionSet = new HashSet<>();
        submissionSet.add(submission1);
        submissionSet.add(submission2);

        NCG ncg = new NCG();
        ncg.setId("1");
        ncg.setUserId(userId);
        ncg.setTeamName("team1");
        ncg.setFirstName("niket");
        ncg.setSubmissions(submissionSet);
        ncg.setTasks(taskList);

        when(ncgRepository.findByUserId(userId)).thenReturn(java.util.Optional.empty());
        when(submissionService.findByUserIdWithTask(userId,task1)).thenReturn(submission1);
        when(submissionService.findByUserIdWithTask(userId,task2)).thenReturn(submission1);
        TaskDto taskDto1 = new TaskDto("1","title1","description","INDIVIDUAL","EASY",123,0,"NOT_SUBMITTED",null);
        TaskDto taskDto2 = new TaskDto("2","title2","description","INDIVIDUAL","EASY",123,0,"NOT_SUBMITTED",null);
        List<TaskDto> taskDtoList = new ArrayList<>();
        taskDtoList.add(taskDto1);
        taskDtoList.add(taskDto2);

        assertThrows(ResponseStatusException.class,() -> {
            List<TaskDto> resdtoList = ncgService.getTaskByUserId(userId);
        });

    }

    /**
     * Positive Test case for getting tasks for team name
     */
    @Test
    public void getTaskByTeamName() {
        String teamName = "team1";
        String userId = "doken";
        Task task1 = new Task("1", "title1", Difficulty.EASY, "description", 123, TaskType.TEAM, false);
        Task task2 = new Task("2", "title2", Difficulty.EASY, "description", 123, TaskType.TEAM, false);
        Submission submission1 = new Submission("1", task1, 0, teamName, State.NOT_SUBMITTED, null);
        Submission submission2 = new Submission("2", task2, 0, teamName, State.NOT_SUBMITTED, null);

        Set<Task> taskList = new HashSet<>();
        taskList.add(task1);
        taskList.add(task2);

        Set<Submission> submissionSet = new HashSet<>();
        submissionSet.add(submission1);
        submissionSet.add(submission2);


        NCG ncg = new NCG();
        ncg.setId("1");
        ncg.setUserId("doken");
        ncg.setTeamName("team1");
        ncg.setFirstName("niket");
        ncg.setSubmissions(submissionSet);
        ncg.setTasks(taskList);

        List<User> ncgList = new ArrayList<>();
        ncgList.add(ncg);

        Team team = new Team("1", "team1", ncgList, taskList, submissionSet, false);


        when(ncgRepository.findByUserId(userId)).thenReturn(java.util.Optional.of(ncg));
        when(submissionService.findByUserIdWithTask(userId, task1)).thenReturn(submission1);
        when(submissionService.findByUserIdWithTask(userId, task2)).thenReturn(submission1);
        when(teamRepository.findByTeamName(teamName)).thenReturn(java.util.Optional.of(team));


        TaskDto taskDto1 = new TaskDto("1", "title1", "description", "TEAM", "EASY", 123, 0, "NOT_SUBMITTED", null);
        TaskDto taskDto2 = new TaskDto("2", "title2", "description", "TEAM", "EASY", 123, 0, "NOT_SUBMITTED", null);
        List<TaskDto> taskDtoList = new ArrayList<>();
        taskDtoList.add(taskDto1);
        taskDtoList.add(taskDto2);

        List<TaskDto> resdtoList = ncgService.getTaskByTeamName(teamName);
        resdtoList.sort((a1, a2) -> Integer.parseInt(a1.getId()) - Integer.parseInt(a2.getId()));
        assertEquals(taskDtoList, resdtoList);
    }
}
