package com.vmware.BootcampManagementSystem.service;



import com.vmware.BootcampManagementSystem.exception.BadRequestException;
import com.vmware.BootcampManagementSystem.repository.TeamRepository;
import com.vmware.BootcampManagementSystem.model.Team;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TeamService {

    private final TeamRepository teamRepository;


    @Autowired
    public TeamService(TeamRepository teamRepository){
        this.teamRepository = teamRepository;
    }

    public void addTeam(Team team){
        Team team1 = getTeamByName(team.getTeamName());
        if(team1 == null){
            teamRepository.save(team);
        } else{
            throw new BadRequestException(team.getTeamName() + " name already exists");
        }
    }

    public List<Team> findAll(){ return teamRepository.findAll();}

    public Team getTeamByName(String teamId){
        return teamRepository.findByTeamName(teamId).orElse(null);
    }
}
