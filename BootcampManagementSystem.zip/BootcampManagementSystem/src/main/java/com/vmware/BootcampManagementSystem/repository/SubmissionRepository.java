package com.vmware.BootcampManagementSystem.repository;

import com.vmware.BootcampManagementSystem.model.Submission;
import com.vmware.BootcampManagementSystem.model.Task;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface SubmissionRepository extends MongoRepository<Submission,String> {

    List<Submission> findAllByTask(Task task);

    //Optional<Submission> findByUserId(String userId);
}
