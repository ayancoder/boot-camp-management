package com.vmware.BootcampManagementSystem.dto;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import lombok.experimental.Accessors;

import javax.validation.constraints.NotBlank;

@Data
@Getter
@Setter
@Accessors(chain = true)
@NoArgsConstructor
@AllArgsConstructor
@ToString
@JsonInclude(value = JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)

public class TaskDto {

    private String id;
    @NotBlank
    @JsonProperty("title")
    private String title;
    @NotBlank
    @JsonProperty("description")
    private String description;
    @NotBlank
    @JsonProperty("task_type")
    private String type;
    @NotBlank
    @JsonProperty("difficulty_level")
    private String level;
    @NotBlank
    @JsonProperty("deadline")
    private long deadLine;
    @JsonProperty("score")
    private int score;
    @JsonProperty("state")
    private String state;
    @JsonProperty("res")
    private String res;


}
