package com.vmware.BootcampManagementSystem.repository;

import com.vmware.BootcampManagementSystem.model.Mentor;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;


public interface MentorRepository extends MongoRepository<Mentor,String> {
    Optional<Mentor> findByUserId(String userId);
}
