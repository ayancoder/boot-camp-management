package com.vmware.BootcampManagementSystem.controller;

import com.vmware.BootcampManagementSystem.converter.AdminConverter;
import com.vmware.BootcampManagementSystem.converter.MentorConverter;
import com.vmware.BootcampManagementSystem.converter.NCGConverter;
import com.vmware.BootcampManagementSystem.converter.UserConverter;
import com.vmware.BootcampManagementSystem.exception.UserNotFoundException;
import com.vmware.BootcampManagementSystem.dto.*;
import com.vmware.BootcampManagementSystem.model.*;
import com.vmware.BootcampManagementSystem.security.JwtProvider;
import com.vmware.BootcampManagementSystem.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import javax.validation.Valid;
import java.time.Instant;
import java.util.List;
import java.util.stream.Collectors;


@RestController
@RequestMapping("api/")
public class UserController {



    final private NCGService ncgService;
    final private AdminService adminService;
    final private MentorService mentorService;
    final private TeamService teamService;
    final private RefreshTokenService refreshTokenService;

    @Autowired
    private final AuthenticationManager authenticationManager;

    private final JwtProvider jwtProvider;

    private final PasswordEncoder passwordEncoder;

    @Autowired
    public UserController(NCGService ncgService, AdminService adminService, MentorService mentorService, TeamService teamService, RefreshTokenService refreshTokenService, AuthenticationManager authenticationManager, JwtProvider jwtProvider, PasswordEncoder passwordEncoder) {
        this.ncgService = ncgService;
        this.adminService = adminService;
        this.mentorService = mentorService;
        this.teamService = teamService;
        this.refreshTokenService = refreshTokenService;
        this.authenticationManager = authenticationManager;
        this.jwtProvider = jwtProvider;
        this.passwordEncoder = passwordEncoder;
    }


    @PostMapping(path="/signup")
    public void addUser(@RequestBody @Valid UserDto userDto) {
        switch (userDto.getRole()) {
            case "NCG":
                NCG ncg = new NCG();
                NCGConverter.toDo(userDto, ncg);
                System.out.println(ncg.getPassword() + "here\n");
                ncg.setPassword(passwordEncoder.encode(ncg.getPassword()));
                ncgService.addUser(ncg);
                break;
            case "MENTOR":
                Mentor mentor = new Mentor();
                MentorConverter.toDo(userDto, mentor);
                mentor.setPassword(passwordEncoder.encode(mentor.getPassword()));
                mentorService.addUser(mentor);
                break;
            case "ADMIN":
                Admin admin = new Admin();
                AdminConverter.toDo(userDto, admin);
                admin.setPassword(passwordEncoder.encode(admin.getPassword()));
                adminService.addUser(admin);
                break;
            default:
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Role not valid");
                //throw new BadRequestException("Role not valid");
        }

    }

    @GetMapping(path = "/user/{userId}")
    public NCGDto getUserById(@PathVariable("userId") String user_id){
        NCG ncg = ncgService.findByUserId(user_id);
        if ( ncg == null ){
            throw new UserNotFoundException("User not found");
        }
        NCGDto ncgDto = new NCGDto();
        NCGConverter.toDto(ncg,ncgDto);
        return ncgDto;
    }

    @GetMapping(path = "/user/{userId}/tasks")
    public List<TaskDto> getTaskById(@PathVariable (name = "userId") String userId,@RequestParam (name="state",required = false, defaultValue = "ALL") String state){
        List<TaskDto> taskDtos =  ncgService.getTaskByUserId(userId);
        if(!state.equals("ALL")){
            taskDtos =  taskDtos.stream().filter(taskDto -> taskDto.getState().equals(state)).collect(Collectors.toList());
            return taskDtos;
        }
        return taskDtos;
    }

    @GetMapping(path = "/user/{userId}/team/{teamName}/tasks")
    public List<TaskDto> getTaskByTeamName( @PathVariable (name = "userId") String userId, @PathVariable (name = "teamName") String teamName, @RequestParam (name="state",required = false, defaultValue = "ALL") String state){
        //System.out.println("whyyyy");
        NCG ncg = ncgService.findByUserId(userId);
        if(ncg == null || !ncg.getTeamName().equals(teamName) ){
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,userId+" not found");
            //throw new BadRequestException("user_id does not exists");
        }

        List<TaskDto> taskDtos = ncgService.getTaskByTeamName(teamName);
        if(!state.equals("ALL")){
            taskDtos =  taskDtos.stream().filter(taskDto -> taskDto.getState().equals(state)).collect(Collectors.toList());
            return taskDtos;
        }
        return taskDtos;
    }

    @PostMapping(path = "/user/{userId}/task/{taskId}/submit")
    public void submitIndividualTask(@PathVariable (name = "userId") String userId, @PathVariable (name = "taskId") String taskId, @RequestBody SubmitRequestDto request){
        ncgService.submitIndividualAssignment(userId,taskId,request.getRes());
    }

    @PostMapping(path = "/user/{userId}/team/{teamName}/task/{taskId}/submit")
    public void submitTeamTask(@PathVariable (name = "userId") String userId,@PathVariable (name = "teamName") String teamName, @PathVariable (name = "taskId") String taskId, @RequestBody SubmitRequestDto request){
        ncgService.submitTeamAssignment(userId,teamName,taskId,request.getRes());
    }

    @PostMapping(path = "/login")
        public AuthenticationResponseDto  login( @RequestBody LoginRequestDto requeat){

        Authentication authenticate = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(requeat.getUserId(),
                requeat.getPassword()));
        SecurityContextHolder.getContext().setAuthentication(authenticate);
        String authenticationToken = jwtProvider.generateToken(authenticate);
        UserDto userDto = new UserDto();
        switch (requeat.getRole()) {
            case "NCG":
                NCG ncg = ncgService.findByUserId(requeat.getUserId());
                UserConverter.toDto(ncg, userDto);
                break;
            case "MENTOR":
                Mentor mentor = mentorService.getUserByID(requeat.getUserId());
                UserConverter.toDto(mentor, userDto);
                break;
            case "ADMIN":
                Admin admin = adminService.getUserByID(requeat.getUserId());
                UserConverter.toDto(admin, userDto);
                break;
            default:
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Role not found");
                //throw new BadRequestException("Role not valid");
        }

        return new AuthenticationResponseDto(authenticationToken,userDto , refreshTokenService.generateRefreshToken().getRefreshToken(), Instant.now().plusMillis(jwtProvider.getJwtExpirationInMillis()));

    }

    @GetMapping(path = "/user/{userId}/team")
    public TeamResponseDto getTeam( @PathVariable("userId") String userId){

        NCG ncg = ncgService.findByUserId(userId);
        if(ncg == null ){
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,userId+" not found");
            //throw new BadRequestException("user_id does not exists");
        }

        Team team = teamService.getTeamByName(ncg.getTeamName());
        if ( team == null ){
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,ncg.getTeamName()+" not found");

            //throw new UserNotFoundException("User not found");
        }

        TeamResponseDto teamResponseDto = new TeamResponseDto();
        teamResponseDto.setTeamId(team.getId());
        teamResponseDto.setTeamName(team.getTeamName());
        teamResponseDto.setUsers(UserConverter.toDto(team.getUsers()));
        return teamResponseDto;
        //return TeamConverter.toDto(team);
    }

    @GetMapping(path = "/leaderboard")
    public List<IndividualLeaderboard> getIndividualLeaderboard (){
        return ncgService.getIndividualLeaderboard();
    }

    @GetMapping(path = "/team/leaderboard")
    public List<TeamLeaderBoard> getTeamLeaderboard (){
        return ncgService.getTeamLeaderboard();
    }


    @GetMapping(path = "/logout")
    public void logout(@Valid @RequestBody RefreshTokenDTo refreshTokenRequest) {
        refreshTokenService.deleteRefreshToken(refreshTokenRequest.getRefreshToken());
    }


    @PostMapping("/refresh/token")
    public AuthenticationResponseDto refreshTokens(@Valid @RequestBody RefreshTokenDTo refreshTokenRequest) {
        return ncgService.refreshToken(refreshTokenRequest);
    }



}
