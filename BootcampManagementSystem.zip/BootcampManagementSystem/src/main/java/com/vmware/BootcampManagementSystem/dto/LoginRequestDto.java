package com.vmware.BootcampManagementSystem.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;

import javax.validation.constraints.NotBlank;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class LoginRequestDto {

    @JsonProperty("user_id")
    @NonNull
    @NotBlank
    private String userId;
    @JsonProperty("password")
    @NotBlank
    @NonNull
    private String password;
    @JsonProperty ("role")

    @NonNull
    @NotBlank
    private String role;

}
