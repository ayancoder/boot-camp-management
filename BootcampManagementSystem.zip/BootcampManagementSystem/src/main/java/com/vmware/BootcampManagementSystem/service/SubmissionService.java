package com.vmware.BootcampManagementSystem.service;

import com.vmware.BootcampManagementSystem.exception.BadRequestException;
import com.vmware.BootcampManagementSystem.repository.SubmissionRepository;
import com.vmware.BootcampManagementSystem.model.Submission;
import com.vmware.BootcampManagementSystem.model.Task;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Service
public class SubmissionService {

    private final SubmissionRepository submissionRepository;


    public SubmissionService(SubmissionRepository submissionRepository) {
        this.submissionRepository = submissionRepository;
    }

    public List<Submission> findAllByTask(Task task){
        return submissionRepository.findAllByTask(task);
    }

    public Submission findByUserIdWithTask(String userId, Task task){

        List<Submission> submissionList = submissionRepository.findAllByTask(task);
        if(submissionList == null){

            throw new ResponseStatusException(HttpStatus.NOT_FOUND,"No tasks found for "+userId);
           // throw new BadRequestException("No tasks for userId found");
        }
        Submission submission = submissionList.stream().filter( x -> x.getSubmitterId().equals(userId)).findFirst().orElse(null);
        if( submission == null ){
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,"No tasks found for "+userId);

            //throw new BadRequestException("No tasks for userId found");
        }

        return submission;
    }

    public void save(Submission submission){
        submissionRepository.save(submission);
    }

    public void saveAll(List<Submission> submissions){
        submissionRepository.saveAll(submissions);
    }
}
