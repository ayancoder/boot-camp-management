package com.vmware.BootcampManagementSystem;
import com.vmware.BootcampManagementSystem.dto.TaskDto;
import com.vmware.BootcampManagementSystem.exception.BadRequestException;
import com.vmware.BootcampManagementSystem.model.*;
import com.vmware.BootcampManagementSystem.repository.NCGRepository;
import com.vmware.BootcampManagementSystem.repository.SubmissionRepository;
import com.vmware.BootcampManagementSystem.repository.TeamRepository;
import com.vmware.BootcampManagementSystem.service.NCGService;
import com.vmware.BootcampManagementSystem.service.SubmissionService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.server.ResponseStatusException;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(SpringRunner.class)
@SpringBootTest
public class SubmissionServiceTests {



    @Mock
    private SubmissionRepository submissionRepository;
    @InjectMocks
    private SubmissionService submissionService;



    /**
     * Positive Test case for submitting individual tasks
     */

    @Test
    public void findByUserIdWithTaskPassTest(){

        String userId = "doken";

        Task task1 = new Task("1","title1", Difficulty.EASY,"description",123, TaskType.INDIVIDUAL,false);
        Task task2 = new Task("2","title2", Difficulty.EASY,"description",123, TaskType.INDIVIDUAL,false);
        Submission submission1 = new Submission("1",task1,0,userId, State.NOT_SUBMITTED,null);
        Submission submission2 = new Submission("2",task1,0,"userId",State.NOT_SUBMITTED,null);
        List<Submission> submissionList = new ArrayList<>();

        submissionList.add(submission1);
        submissionList.add(submission2);

        when(submissionService.findAllByTask(task1)).thenReturn(submissionList);
        when(submissionRepository.findAllByTask(task1)).thenReturn(submissionList);

        Submission result = submissionService.findByUserIdWithTask(userId,task1);

        assertEquals(submission1,result);

    }


    /**
     * Positive Test case for assigning tasks
     */

    @Test
    public void findByUserIdWithTaskThrowExceptionTaskNotFound(){

        String userId = "doken";

        Task task1 = new Task("1","title1", Difficulty.EASY,"description",123, TaskType.INDIVIDUAL,false);
        Task task2 = new Task("2","title2", Difficulty.EASY,"description",123, TaskType.INDIVIDUAL,false);
        Submission submission1 = new Submission("1",task1,0,"1", State.NOT_SUBMITTED,null);
        Submission submission2 = new Submission("2",task1,0,"2",State.NOT_SUBMITTED,null);
        List<Submission> submissionList = new ArrayList<>();

        submissionList.add(submission1);
        submissionList.add(submission2);

        when(submissionService.findAllByTask(task1)).thenReturn(submissionList);
        when(submissionRepository.findAllByTask(task1)).thenReturn(submissionList);
        Submission expected = new Submission("1",task1,0,userId, State.NOT_SUBMITTED,null);
        assertThrows(ResponseStatusException.class, ()->{
            Submission result = submissionService.findByUserIdWithTask(userId,task1);

        });

    }
}
