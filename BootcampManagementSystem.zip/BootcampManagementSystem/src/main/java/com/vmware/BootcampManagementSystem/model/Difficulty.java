package com.vmware.BootcampManagementSystem.model;

public enum Difficulty {
    EASY("EASY"),
    MEDIUM("MEDIUM"),
    DIFFICULT("DIFFICULT");

    private final String level;

    Difficulty(String level){
        this.level = level;
    }

    public String getLevel(){
        return  level;
    }

}
