package com.vmware.BootcampManagementSystem.service;

import com.vmware.BootcampManagementSystem.exception.BadRequestException;
import com.vmware.BootcampManagementSystem.repository.MentorRepository;
import com.vmware.BootcampManagementSystem.repository.NCGRepository;
import com.vmware.BootcampManagementSystem.repository.SubmissionRepository;
import com.vmware.BootcampManagementSystem.repository.TeamRepository;
import com.vmware.BootcampManagementSystem.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.Set;

@Service
public class MentorService {

    private final MentorRepository mentorRepository;

    private final NCGRepository ncgRepository;

    private final SubmissionRepository submissionRepository;

    private final TeamRepository teamRepository;


    @Autowired
    public MentorService(MentorRepository ncgRepository, NCGRepository ncgRepository1, SubmissionRepository submissionRepository, TeamRepository teamRepository) {
        //super(userRepository);
        this.mentorRepository = ncgRepository;

        this.ncgRepository = ncgRepository1;
        this.submissionRepository = submissionRepository;
        this.teamRepository = teamRepository;
    }


    public void addUser(Mentor user) {
        Mentor mentor = getUserByID(user.getUserId());
        if(mentor == null){
            mentorRepository.save(user);
        } else {

            throw new BadRequestException(user.getUserId() + " already exists");
        }
    }

    public Mentor getUserByID(String userId) {
        return mentorRepository.findByUserId(userId).orElse(null);
    }


    @Transactional
    public void evaluateIndividualTask(String userId, String task_id, int score){
        NCG ncg = ncgRepository.findByUserId(userId).orElse(null);

        if(ncg == null){
            throw new BadRequestException(userId + " does not exists");
        }
        Set<Submission> submissions = ncg.getSubmissions();
        Submission submission = submissions.stream().filter(x-> x.getTask().getId().equals(task_id) && x.getSubmitterId().equals(userId) ).findFirst().orElse(null);

        if(submission == null ){
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,task_id+" not found");

           // throw new BadRequestException( task_id + " not found");
        }
        submissions.remove(submission);

        if(submission.getState().equals(State.NOT_SUBMITTED) || submission.getTask().getTaskType().equals(TaskType.TEAM) ){
            throw new BadRequestException("Task not submitted ");
        }
        submission.setScore(score);
        submission.setState(State.EVALUATED);
        submissions.add(submission);
        submissionRepository.save(submission);
        ncg.setSubmissions(submissions);
    }

    @Transactional
    public void evaluateTeamTask(String teamName, String task_id, int score){
        Team team = teamRepository.findByTeamName(teamName).orElse(null);

        if(team == null){
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,teamName+" not found");
            //throw new BadRequestException("user_id does not exists");
        }
        Set<Submission> submissions = team.getSubmissions();
        Submission submission = submissions.stream().filter(x-> x.getTask().getId().equals(task_id) && x.getSubmitterId().equals(teamName) ).findFirst().orElse(null);
        submissions.remove(submission);

        if(submission == null ){
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,task_id+" not found");
//            throw new BadRequestException("task_id not found");
        }

        if(submission.getState().equals(State.NOT_SUBMITTED) || submission.getTask().getTaskType().equals(TaskType.INDIVIDUAL)){
            throw new BadRequestException("Task not submitted ");
        }
        submission.setScore(score);
        submission.setState(State.EVALUATED);
        submissions.add(submission);
        submissionRepository.save(submission);
        team.setSubmissions(submissions);
    }
}
