package com.vmware.BootcampManagementSystem.controller;



import com.vmware.BootcampManagementSystem.service.TeamService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("api/team")
public class TeamController {
    @Autowired
   final private TeamService teamService;


    public TeamController(TeamService teamService) {
        this.teamService = teamService;
    }



/*
    @Transactional
    @PostMapping(path="/add")
    public void addTeam(@RequestBody @Valid TeamDto teamDto) {
        Team team = new Team();
        team.setTeamName(teamDto.getTeamName());

        List<String> userList = Arrays.asList(teamDto.getUsers());
        List<User> users = new ArrayList<>();
        for(String s : userList){
            User user = ncgRepository.findByUserId(s).orElse(null);
            if(user != null){
                users.add(user);
            } else{
                throw new BadRequestException("user_id do not exist");
            }
        }
        Set<User> userSet = team.getUsers();
        userSet.addAll(users);
        team.setUsers(userSet);

        teamService.addTeam(team);
    }


    @GetMapping(path = "/{teamName}")
    public Team getUserById(@PathVariable("teamName") String team_name){
        Team team = teamService.getTeamByName(team_name);
        if ( team == null ){
            throw new UserNotFoundException("User not found");
        }
        return team;
        //return TeamConverter.toDto(team);
    }

 */
}
