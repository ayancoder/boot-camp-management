package com.vmware.BootcampManagementSystem.converter;


import com.vmware.BootcampManagementSystem.dto.TeamDto;
import com.vmware.BootcampManagementSystem.model.Team;
import com.vmware.BootcampManagementSystem.model.User;

import java.util.ArrayList;
import java.util.List;

public class TeamConverter {

    //@Autowired
    //static private UserRepository userRepository;

    public static TeamDto toDo(TeamDto dto){
        return null;
    }

    public static TeamDto toDto(Team team){
        if(team == null) return null;
       TeamDto teamDto = new TeamDto();
       teamDto.setTeamName(team.getTeamName());
       List<String> userList = new ArrayList<>();
       if(team.getUsers().size() > 0){
           User[] users = team.getUsers().toArray(new User[1]);

           for(User u : users){
               userList.add(u.getUserId());
           }
           teamDto.setUsers(userList.toArray(new String[1]));
       }


        return teamDto;
    }


}
