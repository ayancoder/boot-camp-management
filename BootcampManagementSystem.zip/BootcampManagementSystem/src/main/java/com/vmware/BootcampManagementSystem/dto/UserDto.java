package com.vmware.BootcampManagementSystem.dto;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import lombok.experimental.Accessors;
import javax.validation.constraints.NotBlank;


@Data
@Getter
@Setter
@Accessors(chain = true)
@NoArgsConstructor
@ToString
@JsonInclude(value = JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class UserDto {

    @NotBlank
    @JsonProperty("user_id")
    private  String userId;
    @NotBlank
    @JsonProperty("first_name")
    private  String firstName;
    @NotBlank
    @JsonProperty("last_name")
    private  String lastName;
    @NotBlank
    @JsonProperty("password")
    private  String password;
    @NotBlank
    @JsonProperty("role")
    private  String role;

/*
    public UserDto(@JsonProperty("user_id") String userId,
                   @JsonProperty("first_name") String firstName,
                   @JsonProperty("last_name") String lastName,
                   @JsonProperty("password") String password,
                   @JsonProperty("role") String role) {
        this.userId = userId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.password = password;
        this.role = role;
    }*/









}
