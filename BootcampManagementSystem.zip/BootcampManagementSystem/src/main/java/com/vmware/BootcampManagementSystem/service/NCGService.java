package com.vmware.BootcampManagementSystem.service;

import com.vmware.BootcampManagementSystem.converter.TaskConverter;
import com.vmware.BootcampManagementSystem.converter.UserConverter;
import com.vmware.BootcampManagementSystem.dto.AuthenticationResponseDto;
import com.vmware.BootcampManagementSystem.dto.RefreshTokenDTo;
import com.vmware.BootcampManagementSystem.dto.UserDto;
import com.vmware.BootcampManagementSystem.exception.BadRequestException;
import com.vmware.BootcampManagementSystem.repository.*;
import com.vmware.BootcampManagementSystem.dto.TaskDto;
import com.vmware.BootcampManagementSystem.model.*;
import com.vmware.BootcampManagementSystem.security.JwtProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.time.Instant;
import java.util.*;

@Service
public class NCGService{

    private final NCGRepository ncgRepository;

    private final SubmissionRepository submissionRepository;

    private final TeamRepository teamRepository;

    private final IndividualLeaderboardRepository individualLeaderboardRepository;

    private final TeamLeaderboardRepository teamLeaderboardRepository;

    private final SubmissionService submissionService;

    private final RefreshTokenService refreshTokenService;

    private final JwtProvider jwtProvider;


    private final MentorService mentorService;

    private final AdminService adminService;

    @Autowired
    public NCGService(NCGRepository ncgRepository, TaskRepository taskRepository, SubmissionRepository submissionRepository, TeamRepository teamRepository, IndividualLeaderboardRepository individualLeaderboardRepository, TeamLeaderboardRepository teamLeaderboardRepository, SubmissionService submissionService, RefreshTokenService refreshTokenService, JwtProvider jwtProvider, MentorService mentorService, AdminService adminService) {

        this.ncgRepository = ncgRepository;
        this.submissionRepository = submissionRepository;
        this.teamRepository = teamRepository;
        this.individualLeaderboardRepository = individualLeaderboardRepository;
        this.teamLeaderboardRepository = teamLeaderboardRepository;
        this.submissionService = submissionService;
        this.refreshTokenService = refreshTokenService;
        this.jwtProvider = jwtProvider;
        this.mentorService = mentorService;
        this.adminService = adminService;
    }


    public void addUser(User user) {
        NCG ncg = findByUserId(user.getUserId());
        if(ncg == null){
            ncgRepository.save((NCG)user);
        } else{
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,user.getUserId()+" not found");

            //throw  new BadRequestException("user_id already exists");
        }
        IndividualLeaderboard individualLeaderboard = new IndividualLeaderboard();
        individualLeaderboard.setUserId(user.getUserId());
        individualLeaderboardRepository.save(individualLeaderboard);
    }

    public NCG findByUserId(String userId) {
        return ncgRepository.findByUserId(userId).orElse(null);
    }

    public void save(NCG ncg){
        ncgRepository.save(ncg);
    }


    public List<TaskDto> getTaskByUserId(String userId){
        NCG ncg = ncgRepository.findByUserId(userId).orElse(null);
        if(ncg == null){
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,userId+" not found");
//            throw new BadRequestException("user_id not found");
        }
        Task[] taskList = ncg.getTasks().toArray(new Task[1]);
        List<TaskDto> dtos = new ArrayList<>();
        for(Task task : taskList){
            TaskDto taskDto = new TaskDto();
            Submission submission = submissionService.findByUserIdWithTask(userId,task);
           if(submission != null ){
               taskDto.setState(submission.getState().toString());
               taskDto.setScore(submission.getScore());
               taskDto.setRes(submission.getAns());
           } else {
               taskDto.setState(State.NOT_SUBMITTED.toString());
           }
            TaskConverter.toDto(task,taskDto);

            dtos.add(taskDto);
        }
        return dtos;
    }

    public List<TaskDto> getTaskByTeamName( String teamName){



        Team team = teamRepository.findByTeamName(teamName).orElse(null);
        if(team == null){
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,teamName+" not found");
//            throw new BadRequestException("user_id not found");
        }

        Task[] taskList = team.getTaskList().toArray(new Task[1]);
        List<TaskDto> dtos = new ArrayList<>();
        for(Task task : taskList){
            TaskDto taskDto = new TaskDto();
            Submission submission = submissionService.findByUserIdWithTask( teamName,task);
            if(submission != null ){
                taskDto.setState(submission.getState().toString());
                taskDto.setScore(submission.getScore());
                taskDto.setRes(submission.getAns());
            } else {
                taskDto.setState(State.NOT_SUBMITTED.toString());
            }
            TaskConverter.toDto(task,taskDto);

            dtos.add(taskDto);
        }
        return dtos;
    }


    @Transactional
    public void submitIndividualAssignment(String userId, String taskId,String res){
        NCG ncg = ncgRepository.findByUserId(userId).orElse(null);
        if( ncg == null ){
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,userId+" not found");
            //throw new BadRequestException("user_id not found");
        }

        Set<Submission> submissions = ncg.getSubmissions();
        Submission submission = submissions.stream().filter(x-> x.getTask().getId().equals(taskId) && x.getSubmitterId().equals(userId)).findFirst().orElse(null);
        submissions.remove(submission);

        if(submission == null ){
            throw new BadRequestException("task_id not found");
        }

        if(submission.getState().equals(State.EVALUATED)){
            throw new BadRequestException("Task already evaluated");
        }
        submission.setAns(res);
        submission.setState(State.SUBMITTED);
        submissions.add(submission);
        submissionRepository.save(submission);
        ncg.setSubmissions(submissions);
    }


    @Transactional
    public void submitTeamAssignment(String userId, String teamName, String taskId,String res){
        Team team = teamRepository.findByTeamName(teamName).orElse(null);
        if( team == null ){
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,teamName+" not found");
            //throw new BadRequestException("user_id not found");
        }

        if(team.getUsers().size() == 0 ||  ! team.getUsers().get(0).getUserId().equals(userId)){
            throw new BadRequestException(userId + " cannot submit");
        }
        Set<Submission> submissions = team.getSubmissions();
        Submission submission = submissions.stream().filter(x-> x.getTask().getId().equals(taskId) && x.getSubmitterId().equals(teamName)).findFirst().orElse(null);

        if(submission == null ){
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,taskId+" not found");
            //throw new BadRequestException("task_id not found");
        }
        submissions.remove(submission);

        if(submission.getState().equals(State.EVALUATED)){
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,taskId+" not found");
            //throw new BadRequestException("Task already evaluated");
        }
        submission.setAns(res);
        submission.setState(State.SUBMITTED);
        submissions.add(submission);
        submissionRepository.save(submission);
        team.setSubmissions(submissions);
    }


    public List<IndividualLeaderboard> getIndividualLeaderboard(){
        List<IndividualLeaderboard> leaderboards = individualLeaderboardRepository.findAll();
        leaderboards.sort((o1, o2) -> o2.getScore() - o1.getScore());
        return leaderboards;
    }

    public List<TeamLeaderBoard> getTeamLeaderboard(){
        List<TeamLeaderBoard> leaderboards = teamLeaderboardRepository.findAll();
        leaderboards.sort((o1, o2) -> o2.getScore() - o1.getScore());
        return leaderboards;
    }


    private String generateVerificationToken(User user) {
        String token = UUID.randomUUID().toString();
        RefreshToken verificationToken = new RefreshToken();
        verificationToken.setRefreshToken(token);
        verificationToken.setUserId(user.getUserId());
        refreshTokenService.save(verificationToken);
        return token;
    }

    public AuthenticationResponseDto refreshToken(RefreshTokenDTo refreshTokenRequest) {
        refreshTokenService.validateRefreshToken(refreshTokenRequest.getRefreshToken());
        String token = jwtProvider.generateTokenWithUserName(refreshTokenRequest.getUserId());
        AuthenticationResponseDto dto = new AuthenticationResponseDto();
        dto.setAuthenticationToken(token);
        dto.setRefreshToken(refreshTokenRequest.getRefreshToken());
        dto.setExpiresAt(Instant.now().plusMillis(jwtProvider.getJwtExpirationInMillis()));
        UserDto userDto = new UserDto();
        switch (refreshTokenRequest.getRole()) {
            case "NCG":
                NCG ncg = findByUserId(refreshTokenRequest.getUserId());
                if(ncg == null ){
                    throw new ResponseStatusException(HttpStatus.NOT_FOUND,"user not found");
                    //throw new BadRequestException("user id not present");
                }
                UserConverter.toDto(ncg, userDto);
                break;
            case "MENTOR":
                Mentor mentor = mentorService.getUserByID(refreshTokenRequest.getUserId());
                if(mentor == null ){
                    throw new ResponseStatusException(HttpStatus.NOT_FOUND,"user not found");
                    //throw new BadRequestException("user id not present");
                }
                UserConverter.toDto(mentor, userDto);
                break;
            case "ADMIN":
                Admin admin = adminService.getUserByID(refreshTokenRequest.getUserId());
                if(admin == null ){
                    throw new ResponseStatusException(HttpStatus.NOT_FOUND,"user not found");
                    //throw new BadRequestException("user id not present");
                }
                UserConverter.toDto(admin, userDto);
                break;
            default:
                throw new BadRequestException("Role not valid");
        }
        dto.setUser(userDto);
        return dto;
    }





}
