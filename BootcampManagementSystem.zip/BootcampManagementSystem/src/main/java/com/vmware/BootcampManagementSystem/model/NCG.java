package com.vmware.BootcampManagementSystem.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;


import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Document
public class NCG extends User {

    @DBRef
    private List<Mentor> mentors = new ArrayList<>();

    private String teamName;
    @DBRef
    private Set<Task> tasks = new HashSet<>();
    @DBRef
    private Set<Submission> submissions = new HashSet<>();



    @Override
    public int hashCode() {
        int result = 17;
        result = 31 * result + this.getId().hashCode();
        return result;
    }

}
